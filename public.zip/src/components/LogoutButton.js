import React from 'react';
import { useNavigate } from 'react-router-dom';

const LogoutButton = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await fetch('http://localhost:3000/api/auth/logout', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'authorization': `Bearer ${localStorage.getItem('token')}`
         }
      });

      localStorage.removeItem('token');
      navigate('/signin');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  return (
    <button
      type="button"
      className="bg-slate-800 shadow-lg w-full text-white rounded-lg p-2"
      onClick={handleLogout}
    >
      Logout
    </button>
  );
};

export default LogoutButton;
